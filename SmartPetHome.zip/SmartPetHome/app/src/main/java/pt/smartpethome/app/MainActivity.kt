package pt.smartpethome.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import pt.smartpethome.app.data.SemasRepository
import pt.smartpethome.app.sync.SyncWorker
import pt.smartpethome.app.ui.AppRoot
import pt.smartpethome.app.ui.theme.SmartPetHomeTheme
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 🔥 FIRESTORE LISTENER (TEM DE ESTAR AQUI)
        val repo = SemasRepository.get(this)
        repo.startListeningCurrentState("pet_home_01")

        // Periodic sync (every 15 min - WorkManager minimum)
        val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "semas_sync",
            ExistingPeriodicWorkPolicy.UPDATE,
            req
        )

        setContent {
            SmartPetHomeTheme {
                AppRoot()
            }
        }
    }
}
