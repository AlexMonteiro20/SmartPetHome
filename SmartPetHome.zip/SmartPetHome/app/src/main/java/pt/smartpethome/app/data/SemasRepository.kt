package pt.smartpethome.app.data

import android.content.Context
import androidx.room.Room
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pt.smartpethome.app.data.db.AppDatabase
import pt.smartpethome.app.data.model.Actuation
import pt.smartpethome.app.data.model.SensorReading
import pt.smartpethome.app.data.model.Spot
import pt.smartpethome.app.data.remote.ActuationRequestDto
import pt.smartpethome.app.data.remote.ApiClient

class SemasRepository private constructor(
    private val db: AppDatabase
) {

    /* -------------------------------
     * REMOTE API (Cloud Run / REST)
     * ------------------------------- */
    private val api = ApiClient.build()

    /* -------------------------------
     * FIREBASE
     * ------------------------------- */
    private val firestore = FirebaseFirestore.getInstance()
    private var stateListener: ListenerRegistration? = null

    /* -------------------------------
     * ROOM OBSERVERS
     * ------------------------------- */
    fun observeSpots(): Flow<List<Spot>> =
        db.spotDao().observeAll()

    fun observeReadings(spotId: String): Flow<List<SensorReading>> =
        db.readingDao().observeLatestForSpot(spotId, 100)

    fun observeActuations(spotId: String): Flow<List<Actuation>> =
        db.actuationDao().observeForSpot(spotId, 50)

    /* -------------------------------
     * FIREBASE → ROOM (REALTIME)
     * ------------------------------- */
    fun startListeningCurrentState(spotId: String) {
        stateListener?.remove()

        stateListener = firestore
            .collection("estado_atual")
            .document(spotId)
            .addSnapshotListener { snap, err ->
                if (err != null || snap == null || !snap.exists()) return@addSnapshotListener

                val temp = snap.getDouble("tempC")
                val dist = snap.getLong("distCm")
                val foodState = snap.getString("foodState")

                // 🔥 CORREÇÃO: usar serverTs
                val ts = snap.getTimestamp("serverTs")
                    ?.toDate()
                    ?.time ?: System.currentTimeMillis()

                val readings = mutableListOf<SensorReading>()

                temp?.let {
                    readings.add(
                        SensorReading(
                            spotId = spotId,
                            type = "tempC",
                            value = it,
                            timestamp = ts,
                            source = "firebase"
                        )
                    )
                }

                dist?.let {
                    readings.add(
                        SensorReading(
                            spotId = spotId,
                            type = "distCm",
                            value = it.toDouble(),
                            timestamp = ts,
                            source = "firebase"
                        )
                    )
                }

                foodState?.let {
                    val mappedValue = when (it.uppercase()) {
                        "FULL" -> 2.0
                        "MID" -> 1.0
                        "EMPTY" -> 0.0
                        else -> 0.0
                    }

                    readings.add(
                        SensorReading(
                            spotId = spotId,
                            type = "foodState",
                            value = mappedValue,
                            timestamp = ts,
                            source = "firebase"
                        )
                    )
                }

                if (readings.isNotEmpty()) {
                    GlobalScope.launch(Dispatchers.IO) {
                        db.readingDao().upsertAll(readings)
                    }
                }
            }
    }

    fun stopListening() {
        stateListener?.remove()
        stateListener = null
    }

    /* -------------------------------
     * SYNC VIA API (HISTÓRICO)
     * ------------------------------- */
    suspend fun syncSpotsAndReadings() = withContext(Dispatchers.IO) {
        val remoteSpots = api.getSpots()
            .map { Spot(it.id, it.name, it.lat, it.lon, it.createdAt) }

        db.spotDao().upsertAll(remoteSpots)

        for (s in remoteSpots) {
            val readings = api.getReadings(s.id, 100).map {
                SensorReading(
                    id = it.id,
                    spotId = it.spotId,
                    type = it.type,
                    value = it.value,
                    timestamp = it.timestamp,
                    source = "remote"
                )
            }
            db.readingDao().upsertAll(readings)
        }
    }

    /* -------------------------------
     * ACTUATION (APP → CLOUD)
     * ------------------------------- */
    suspend fun sendActuation(
        spotId: String,
        type: String,
        value: String
    ): String = withContext(Dispatchers.IO) {

        val act = Actuation(spotId = spotId, type = type, value = value)
        db.actuationDao().upsert(act)

        try {
            val resp = api.postActuation(
                ActuationRequestDto(spotId, type, value, act.timestamp)
            )
            db.actuationDao().updateStatus(act.id, resp.status)
            resp.id
        } catch (e: Exception) {
            db.actuationDao().updateStatus(act.id, "FAILED")
            throw e
        }
    }

    /* -------------------------------
     * SINGLETON
     * ------------------------------- */
    companion object {
        @Volatile
        private var INSTANCE: SemasRepository? = null

        fun get(context: Context): SemasRepository =
            INSTANCE ?: synchronized(this) {
                val db = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "semas.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()

                SemasRepository(db).also { INSTANCE = it }
            }
    }
}
