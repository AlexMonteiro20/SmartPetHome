package pt.smartpethome.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import pt.smartpethome.app.data.model.Actuation

@Dao
interface ActuationDao {
    @Query("SELECT * FROM actuations WHERE spotId = :spotId ORDER BY timestamp DESC LIMIT :limit")
    fun observeForSpot(spotId: String, limit: Int = 50): Flow<List<Actuation>>

    @Query("SELECT * FROM actuations WHERE status = 'PENDING' ORDER BY timestamp ASC")
    suspend fun getPending(): List<Actuation>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(actuation: Actuation)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(actuations: List<Actuation>)

    @Query("UPDATE actuations SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)
}
