package pt.smartpethome.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import pt.smartpethome.app.data.model.Actuation
import pt.smartpethome.app.data.model.SensorReading
import pt.smartpethome.app.data.model.Spot

@Database(
    entities = [Spot::class, SensorReading::class, Actuation::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun spotDao(): SpotDao
    abstract fun readingDao(): ReadingDao
    abstract fun actuationDao(): ActuationDao
}
