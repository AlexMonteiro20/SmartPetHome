package pt.smartpethome.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import pt.smartpethome.app.data.model.SensorReading

@Dao
interface ReadingDao {
    @Query("SELECT * FROM readings WHERE spotId = :spotId ORDER BY timestamp DESC LIMIT :limit")
    fun observeLatestForSpot(spotId: String, limit: Int = 100): Flow<List<SensorReading>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(readings: List<SensorReading>)

    @Query("DELETE FROM readings WHERE spotId = :spotId AND timestamp < :olderThan")
    suspend fun prune(spotId: String, olderThan: Long)
}
