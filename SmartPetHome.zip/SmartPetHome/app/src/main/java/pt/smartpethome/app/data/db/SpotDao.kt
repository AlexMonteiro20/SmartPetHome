package pt.smartpethome.app.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import pt.smartpethome.app.data.model.Spot

@Dao
interface SpotDao {
    @Query("SELECT * FROM spots ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Spot>>

    @Query("SELECT * FROM spots WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): Spot?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(spots: List<Spot>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(spot: Spot)

    @Delete
    suspend fun delete(spot: Spot)
}
