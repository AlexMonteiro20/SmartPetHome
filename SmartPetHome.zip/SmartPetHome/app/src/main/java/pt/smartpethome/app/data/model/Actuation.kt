package pt.smartpethome.app.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
    tableName = "actuations",
    indices = [Index(value = ["spotId", "timestamp"])]
)
data class Actuation(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val spotId: String,
    val type: String,          // e.g. "buzzer", "pump", "light"
    val value: String,         // e.g. "ON"/"OFF" or numeric
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "PENDING" // PENDING, SENT, ACK, FAILED
)
