package pt.smartpethome.app.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
    tableName = "readings",
    indices = [Index(value = ["spotId", "timestamp"])]
)
data class SensorReading(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val spotId: String,
    val type: String,          // e.g. "tempC", "distCm"
    val value: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val source: String = "remote" // "remote" or "local"
)
