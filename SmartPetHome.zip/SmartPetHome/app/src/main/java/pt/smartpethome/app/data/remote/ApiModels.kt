package pt.smartpethome.app.data.remote

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SpotDto(
    val id: String,
    val name: String,
    val lat: Double,
    val lon: Double,
    val createdAt: Long
)

@JsonClass(generateAdapter = true)
data class ReadingDto(
    val id: String,
    val spotId: String,
    val type: String,
    val value: Double,
    val timestamp: Long
)

@JsonClass(generateAdapter = true)
data class IngestDto(
    val deviceId: String,
    val distCm: Int? = null,
    val tempC: Double? = null,
    val timestamp: Long? = null
)

@JsonClass(generateAdapter = true)
data class ActuationRequestDto(
    val spotId: String,
    val type: String,
    val value: String,
    val timestamp: Long? = null
)

@JsonClass(generateAdapter = true)
data class ActuationResponseDto(
    val id: String,
    val status: String
)
