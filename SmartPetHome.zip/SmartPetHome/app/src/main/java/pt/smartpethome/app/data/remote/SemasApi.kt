package pt.smartpethome.app.data.remote

import retrofit2.http.*

interface SemasApi {
    @GET("spots")
    suspend fun getSpots(): List<SpotDto>

    @GET("spots/{spotId}/readings")
    suspend fun getReadings(
        @Path("spotId") spotId: String,
        @Query("limit") limit: Int = 100
    ): List<ReadingDto>

    @POST("actuate")
    suspend fun postActuation(@Body req: ActuationRequestDto): ActuationResponseDto
}
