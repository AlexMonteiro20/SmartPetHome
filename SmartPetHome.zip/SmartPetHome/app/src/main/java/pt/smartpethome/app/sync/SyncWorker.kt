package pt.smartpethome.app.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import pt.smartpethome.app.data.SemasRepository

class SyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            SemasRepository.get(applicationContext).syncSpotsAndReadings()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
