package pt.smartpethome.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import pt.smartpethome.app.data.SemasRepository

enum class Screen { SPOTS, MAP, DETAIL }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val repo = remember { SemasRepository.get(ctx) }

    var screen by remember { mutableStateOf(Screen.SPOTS) }
    var selectedSpotId by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("SmartPetHome") }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = screen == Screen.SPOTS,
                    onClick = { screen = Screen.SPOTS },
                    label = { Text("Spots") },
                    icon = { Icon(imageVector = Icons.Filled.List, contentDescription = null) }
                )
                NavigationBarItem(
                    selected = screen == Screen.MAP,
                    onClick = { screen = Screen.MAP },
                    label = { Text("Mapa") },
                    icon = { Icon(imageVector = Icons.Filled.Place, contentDescription = null) }
                )
            }
        }
    ) { innerPadding ->
        when (screen) {
            Screen.SPOTS -> SpotsScreen(
                repo = repo,
                modifier = Modifier.padding(innerPadding),
                onOpenSpot = {
                    selectedSpotId = it
                    screen = Screen.DETAIL
                }
            )

            Screen.MAP -> MapScreen(
                repo = repo,
                modifier = Modifier.padding(innerPadding),
                onOpenSpot = {
                    selectedSpotId = it
                    screen = Screen.DETAIL
                }
            )

            Screen.DETAIL -> SpotDetailScreen(
                repo = repo,
                spotId = selectedSpotId ?: return@Scaffold,
                modifier = Modifier.padding(innerPadding),
                onBack = { screen = Screen.SPOTS }
            )
        }
    }
}

