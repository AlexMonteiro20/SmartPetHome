package pt.smartpethome.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.layout.Spacer

import pt.smartpethome.app.data.model.SensorReading

import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet

import android.graphics.Color
import com.github.mikephil.charting.components.XAxis

@Composable
fun ChartsScreen(
    readings: List<SensorReading>
) {
    Column(modifier = Modifier.fillMaxSize()) {

        Text(
            text = "Histórico de Temperatura",
            style = MaterialTheme.typography.titleLarge
        )

        TemperatureChart(readings)

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Histórico do Nível de Comida",
            style = MaterialTheme.typography.titleLarge
        )

        DistanceChart(readings)
    }
}

@Composable
fun TemperatureChart(readings: List<SensorReading>) {

    val tempReadings = readings
        .filter { it.type == "tempC" }
        .sortedBy { it.timestamp }

    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp),
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                axisRight.isEnabled = false
                xAxis.position = XAxis.XAxisPosition.BOTTOM
            }
        },
        update = { chart ->

            val entries = tempReadings.mapIndexed { index, r ->
                Entry(index.toFloat(), r.value.toFloat())
            }

            val dataSet = LineDataSet(entries, "Temperatura (°C)").apply {
                color = Color.parseColor("#2196F3")
                lineWidth = 2f

                setDrawCircles(false)
                setDrawValues(false)

                mode = LineDataSet.Mode.CUBIC_BEZIER
                cubicIntensity = 0.2f
            }

            chart.data = LineData(dataSet)

            // 🔧 Ajustes VISUAIS IMPORTANTES
            chart.description.isEnabled = false
            chart.axisRight.isEnabled = false

            chart.xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
            }

            chart.axisLeft.apply {
                setDrawGridLines(true)
                granularity = 1f
            }

            chart.invalidate()
        }

    )
}

@Composable
fun DistanceChart(readings: List<SensorReading>) {

    val distReadings = readings
        .filter { it.type == "distCm" }
        .sortedBy { it.timestamp }

    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp),
        factory = { context ->
            LineChart(context).apply {
                description.isEnabled = false
                axisRight.isEnabled = false
                xAxis.position = XAxis.XAxisPosition.BOTTOM
            }
        },
        update = { chart ->

            val entries = distReadings.mapIndexed { index, r ->
                Entry(index.toFloat(), r.value.toFloat())
            }

            val dataSet = LineDataSet(entries, "Distância (cm)").apply {
                color = Color.parseColor("#4CAF50") // verde
                lineWidth = 2f

                setDrawCircles(false)
                setDrawValues(false)

                mode = LineDataSet.Mode.CUBIC_BEZIER
                cubicIntensity = 0.2f
            }

            chart.data = LineData(dataSet)

            chart.xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
            }

            chart.axisLeft.apply {
                setDrawGridLines(true)
                granularity = 1f
            }

            chart.invalidate()
        }
    )
}