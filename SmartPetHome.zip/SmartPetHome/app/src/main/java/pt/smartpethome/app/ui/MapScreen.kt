package pt.smartpethome.app.ui

import android.preference.PreferenceManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import pt.smartpethome.app.data.SemasRepository

@Composable
fun MapScreen(
    repo: SemasRepository,
    modifier: Modifier = Modifier,
    onOpenSpot: (String) -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val spots by repo.observeSpots().collectAsState(initial = emptyList())

    LaunchedEffect(Unit) {
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx))
    }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = {
            MapView(it).apply {
                setTileSource(TileSourceFactory.MAPNIK)
                setMultiTouchControls(true)
                controller.setZoom(15.0)
                controller.setCenter(GeoPoint(41.1496, -8.6109)) // Porto default
            }
        },
        update = { map ->
            map.overlays.removeAll { it is Marker }
            for (s in spots) {
                val marker = Marker(map).apply {
                    position = GeoPoint(s.lat, s.lon)
                    title = s.name
                    setOnMarkerClickListener { _, _ ->
                        onOpenSpot(s.id)
                        true
                    }
                }
                map.overlays.add(marker)
            }
            if (spots.isNotEmpty()) {
                map.controller.setCenter(GeoPoint(spots[0].lat, spots[0].lon))
            }
            map.invalidate()
        }
    )
}
