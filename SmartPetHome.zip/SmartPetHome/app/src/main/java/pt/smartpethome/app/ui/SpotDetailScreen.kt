package pt.smartpethome.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import pt.smartpethome.app.data.SemasRepository
import pt.smartpethome.app.data.model.SensorReading
import pt.smartpethome.app.ui.ChartsScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotDetailScreen(
    repo: SemasRepository,
    spotId: String,
    modifier: Modifier = Modifier,
    onBack: () -> Unit
) {
    LaunchedEffect(spotId) {
        repo.startListeningCurrentState(spotId)
    }

    DisposableEffect(Unit) {
        onDispose {
            repo.stopListening()
        }
    }

    val scope = rememberCoroutineScope()
    val spots by repo.observeSpots().collectAsState(initial = emptyList())
    val spot = spots.firstOrNull { it.id == spotId }
    val readings by repo.observeReadings(spotId).collectAsState(initial = emptyList())
    val actuations by repo.observeActuations(spotId).collectAsState(initial = emptyList())

    //  POP-UP — estado atual e controlo
    var showFoodAlert by remember { mutableStateOf(false) }
    var foodStatus by remember { mutableStateOf<String?>(null) }

    val lastDistance = readings
        .lastOrNull { it.type == "distCm" }
        ?.value

    //  POP-UP — detetar mudança de estado
    LaunchedEffect(readings) {
        val lastDist = readings
            .filter { it.type == "distCm" }
            .maxByOrNull { it.timestamp }
            ?.value ?: return@LaunchedEffect

        val newStatus = when {
            lastDist <= 7 -> "CHEIO"
            lastDist <= 14 -> "MEIO"
            else -> "VAZIO"
        }

        if (newStatus != foodStatus) {
            foodStatus = newStatus
            showFoodAlert = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(spot?.name ?: "Spot") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    IconButton(onClick = { scope.launch { runCatching { repo.syncSpotsAndReadings() } } }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Sync")
                    }
                }
            )
        }
    ) { inner ->

        if (showFoodAlert && foodStatus != null) {
            AlertDialog(
                onDismissRequest = { showFoodAlert = false },
                confirmButton = {
                    TextButton(onClick = { showFoodAlert = false }) {
                        Text("OK")
                    }
                },
                title = { Text("Estado do Recipiente") },
                text = {
                    Text(
                        when (foodStatus) {
                            "VAZIO" -> "⚠️ O recipiente está vazio!"
                            "MEIO" -> "ℹ️ O recipiente está a meio."
                            else -> "✅ O recipiente está cheio."
                        }
                    )
                }
            )
        }

        LazyColumn(
            modifier = modifier.padding(inner).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Atuação", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FilledTonalButton(onClick = {
                                scope.launch { runCatching { repo.sendActuation(spotId, "buzzer", "ON") } }
                            }) {
                                Icon(Icons.Default.Power, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Buzzer ON")
                            }
                            FilledTonalButton(onClick = {
                                scope.launch { runCatching { repo.sendActuation(spotId, "buzzer", "OFF") } }
                            }) { Text("OFF") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FilledTonalButton(onClick = {
                                scope.launch { runCatching { repo.sendActuation(spotId, "light", "ON") } }
                            }) { Text("Light ON") }
                            FilledTonalButton(onClick = {
                                scope.launch { runCatching { repo.sendActuation(spotId, "light", "OFF") } }
                            }) { Text("OFF") }
                        }
                        Text("Últimos comandos: ${actuations.take(3).joinToString { it.type + ":" + it.value + "(" + it.status + ")" }}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item { ChartsScreen( readings = readings) }
            item { Text("Leituras (últimas 100)", style = MaterialTheme.typography.titleMedium) }

            items(readings) { r -> ReadingRow(r) }

            if (readings.isEmpty()) {
                item {
                    Text("Ainda não há leituras. Inicia o backend e o simulador (ver README).")
                }
            }
        }
    }
}

@Composable
private fun ReadingRow(r: SensorReading) {
    ElevatedCard {
        Row(
            Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(r.type, style = MaterialTheme.typography.titleSmall)
                Text(java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date(r.timestamp)),
                    style = MaterialTheme.typography.bodySmall)
            }
            Text(r.value.toString(), style = MaterialTheme.typography.titleMedium)
        }
    }
}
