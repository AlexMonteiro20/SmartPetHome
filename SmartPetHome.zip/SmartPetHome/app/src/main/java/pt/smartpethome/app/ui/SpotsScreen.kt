package pt.smartpethome.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import pt.smartpethome.app.data.SemasRepository
import pt.smartpethome.app.data.model.Spot

@Composable
fun SpotsScreen(
    repo: SemasRepository,
    modifier: Modifier = Modifier,
    onOpenSpot: (String) -> Unit
) {
    val spots by repo.observeSpots().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var showAdd by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AssistChip(
                    onClick = {
                        scope.launch {
                            runCatching { repo.syncSpotsAndReadings() }
                        }
                    },
                    label = { Text("Sync agora") }
                )
            }
            items(spots) { spot ->
                SpotCard(spot = spot, onClick = { onOpenSpot(spot.id) })
            }
            if (spots.isEmpty()) {
                item {
                    Text(
                        "Sem spots ainda. Cria um spot ou corre o backend + simulador para aparecerem automaticamente.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        FloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier
                .align(androidx.compose.ui.Alignment.BottomEnd)
                .padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "Adicionar") }
    }

    if (showAdd) {
        AddSpotDialog(
            onDismiss = { showAdd = false },
            onAdd = { name, lat, lon ->
                scope.launch {
                    repo.addSpot(name, lat, lon)
                    showAdd = false
                }
            }
        )
    }
}

private fun SemasRepository.addSpot(
    name: String,
    lat: Double,
    lon: Double
) {
}

@Composable
private fun SpotCard(spot: Spot, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick) {
        Column(Modifier.padding(16.dp)) {
            Text(spot.name, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text("Lat: %.5f, Lon: %.5f".format(spot.lat, spot.lon), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AddSpotDialog(onDismiss: () -> Unit, onAdd: (String, Double, Double) -> Unit) {
    var name by remember { mutableStateOf(TextFieldValue("Meu Spot")) }
    var lat by remember { mutableStateOf(TextFieldValue("41.1496")) } // Porto default
    var lon by remember { mutableStateOf(TextFieldValue("-8.6109")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                onAdd(
                    name.text.trim().ifEmpty { "Spot" },
                    lat.text.toDoubleOrNull() ?: 0.0,
                    lon.text.toDoubleOrNull() ?: 0.0
                )
            }) { Text("Adicionar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        title = { Text("Adicionar Spot") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome") })
                OutlinedTextField(value = lat, onValueChange = { lat = it }, label = { Text("Latitude") })
                OutlinedTextField(value = lon, onValueChange = { lon = it }, label = { Text("Longitude") })
            }
        }
    )
}
